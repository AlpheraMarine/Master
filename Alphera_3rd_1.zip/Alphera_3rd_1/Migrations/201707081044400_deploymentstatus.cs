namespace Alphera_3rd_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class deploymentstatus : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
