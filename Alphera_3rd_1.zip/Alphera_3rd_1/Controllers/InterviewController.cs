﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Alphera_3rd_1.Models;
using Alphera_3rd_1.Helpers;

namespace Alphera_3rd_1.Controllers
{
    public class InterviewController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Interview
        public ActionResult Index(string statusString)
        {
            int interviewStatusPending = 1;
            int interviewStatusPassed = 2;
            int interviewStatusReject = 3;

            //var errMsg = TempData["ErrorMessage"] as string;

            ViewBag.Status = (from s in db.InterviewResultStatus
                              where s.InterviewResultStatusID == interviewStatusPending || s.InterviewResultStatusID == interviewStatusPassed || s.InterviewResultStatusID == interviewStatusReject
                              select s.InterviewResultStatusName).Distinct();
            if (!string.IsNullOrEmpty(statusString))
            {
                var status = from r in db.Interviews
                             orderby r.InterviewResultStatus.InterviewResultStatusName
                             where r.InterviewResultStatus.InterviewResultStatusName == statusString
                             select r;
                return View(status.ToList());
            }

            var interviews = db.Interviews.Include(i => i.Applicant).Include(i => i.InterviewResultStatus);
            return View(interviews.ToList());
        }

        // GET: Interview/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Interview interview = db.Interviews.Find(id);
            if (interview == null)
            {
                return HttpNotFound();
            }
            return View(interview);
        }

        // GET: Interview/Create
        public ActionResult Create()
        {

            //Only show applicants with status of "Accepted"
            string applicantStatusName = "Pending";

            ViewBag.ApplicantID = new SelectList(db.Applicants.Where(a => a.ApplicantStatus.ApplicantStatusName == applicantStatusName), "ApplicantID", "FullName");
            ViewBag.InterviewResultStatusID = new SelectList(db.InterviewResultStatus, "InterviewResultStatusID", "InterviewResultStatusName");
            return View();
        }

        // POST: Interview/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "InterviewID,ApplicantID,InterviewTitle,InterviewDate,InterviewTime,InterviewResultStatusID,InterviewRemark")] Interview interview)
        {
            Applicant applicant = new Applicant();
            int applicantID = interview.ApplicantID;
            int interviewstatus = interview.InterviewResultStatusID;
            

            applicant = (from a in db.Applicants
                         where a.ApplicantID == applicantID
                         select a).First();

            if (ModelState.IsValid)
            {
                
                int certificates = applicant.CertificateID;
                int licenses = applicant.LicenseID;

                //interviewstatus: 1=pending , 2=accepted , 3=rejected
                //licenses/sertificates = 1=pending , 2=complete, 3=incomplete

                db.Interviews.Add(interview);
                //CASES WHERE INTERVIEW CAN BE ACCEPTED
                //change applicant status to "CREWED" IF passed the interview
                if ((interviewstatus == 2 && licenses == 2 && certificates == 2 && interview.InterviewDate > DateTime.Now) || ( interviewstatus == 2 && licenses == 1 && certificates == 1 && interview.InterviewDate > DateTime.Now))
                {
                    applicant.ApplicantStatusID = 4; //Crewed
                }

                //Error message if applicant is incomplete with requirements or pending or date time is past
                #region
                //if interview status is passed & licenses/certificates pending/rejected & interview date > today
                else if (interviewstatus == 2 && licenses == 1 && certificates == 1 || licenses == 3 || certificates == 3 && interview.InterviewDate > DateTime.Now)
                {
                    ViewBag.ErrorMessage = "Applicant must have complete licenses and certificates";
                    return RedirectToAction("Index");
                }

                // interview date > today or set in past
                else if (interview.InterviewDate < DateTime.Now)
                {
                    ViewBag.ErrorMessage = "Interview date can not be set at a past date.";
                    return RedirectToAction("Index");
                }

                //if interview status is rejected & interview date > today
                else if (interviewstatus == 3 && interview.InterviewDate > DateTime.Now)
                {
                    ViewBag.ErrorMessage = "Applicant has been rejected.";
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                //if interview status is pending && liceses
                else if (interviewstatus == 1 && licenses == 1 && certificates == 1 && interview.InterviewDate > DateTime.Now)
                {
                    ViewBag.ErrorMessage = "Applicant has been added to schedules.";
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }

                //if interview date is set today
                else if (interview.InterviewDate == DateTime.Today)
                {
                    TempData["notice"] = "Interview can not be set on short notice";
                    return RedirectToAction("Create");
                }
                #endregion

                string messageBody = MailSender.CreateMessageFromTemplate(Server.MapPath("~/App_Data/Templates/Email.html"), interview.Applicant.FirstName, interview.Applicant.MiddleName, interview.Applicant.LastName, interview.Applicant.Email, interview.InterviewDate.ToShortDateString(), interview.Applicant.Rank.RankName, interview.InterviewTime.ToShortTimeString());

                MailSender.SendMail("jason.morales@benilde.edu.ph", applicant.FullName, applicant.Email, string.Empty, "Alphera Marine Services Incorporated", messageBody, null);
                //Call Email Function

                db.SaveChanges();                

                return RedirectToAction("Index");
            }

            ViewBag.ApplicantID = new SelectList(db.Applicants, "ApplicantID", "FullName", interview.ApplicantID);
            ViewBag.InterviewResultStatusID = new SelectList(db.InterviewResultStatus, "InterviewResultStatusID", "InterviewResultStatusName", interview.InterviewResultStatusID);
            return View(interview);
        }

        // GET: Interview/Edit/5
        public ActionResult Edit(int? id)
        {

            Interview interview = db.Interviews.Find(id);

            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            
            if (interview == null)
            {
                return HttpNotFound();
            }

            ViewBag.ApplicantID = new SelectList(db.Applicants, "ApplicantID", "FullName", interview.ApplicantID);
            ViewBag.InterviewResultStatusID = new SelectList(db.InterviewResultStatus, "InterviewResultStatusID", "InterviewResultStatusName", interview.InterviewResultStatusID);
            return View(interview);
        }

        // POST: Interview/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "InterviewID,ApplicantID,InterviewTitle,InterviewDate,InterviewTime,InterviewResultStatusID,InterviewRemark")] Interview interview)
        {

            Applicant applicant = new Applicant();
            int applicantID = interview.ApplicantID;
            int interviewstatus = interview.InterviewResultStatusID;

            applicant = (from a in db.Applicants
                         where a.ApplicantID == applicantID
                         select a).First();

            if (ModelState.IsValid)
            {
                int certificates = applicant.CertificateID;
                int licenses = applicant.LicenseID;

                db.Entry(interview).State = EntityState.Modified;

                if (interviewstatus == 2 && licenses == 2 && certificates == 2)
                {
                    applicant.ApplicantStatusID = 4; //Crewed
                }
                //Error message if applicant is incomplete with requirements or pending or date time is past
                #region
                else if (interviewstatus == 2 && licenses == 1 && certificates == 1 || licenses == 3 || certificates == 3)
                {
                    ViewBag.ErrorMessage = "Applicant must have complete licenses and certificates";
                    TempData["ErrorMessage"] = "This is the message";
                    return RedirectToAction("Index");
                }
                else if (interview.InterviewDate < DateTime.Now)
                {
                    ViewBag.ErrorMessage = "Interview date can not be set at a past date.";
                    return RedirectToAction("Index");
                }
                else if (interviewstatus == 3)
                {
                    ViewBag.ErrorMessage = "Applicant has been rejected.";
                    return RedirectToAction("Index");
                }
                else if (interviewstatus == 1 && licenses == 1 && certificates == 1) //if all are pending 
                    //allowed pending if requirements are pending
                {
                    ViewBag.ErrorMessage = "Applicant has been added to schedules.";
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
                #endregion


                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ApplicantID = new SelectList(db.Applicants, "ApplicantID", "FullName", interview.ApplicantID);
            ViewBag.InterviewResultStatusID = new SelectList(db.InterviewResultStatus, "InterviewResultStatusID", "InterviewResultStatusName", interview.InterviewResultStatusID);
            return View(interview);
        }

        // GET: Interview/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Interview interview = db.Interviews.Find(id);
            if (interview == null)
            {
                return HttpNotFound();
            }
            return View(interview);
        }

        // POST: Interview/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Interview interview = db.Interviews.Find(id);
            db.Interviews.Remove(interview);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
