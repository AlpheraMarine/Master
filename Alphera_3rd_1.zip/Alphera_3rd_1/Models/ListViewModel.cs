﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Web;
using System.IO;
using System.Web.Mvc;

namespace Alphera_3rd_1.Models
{
    public class ListViewModel
    {
    }
    /*
    public class RankViewModel
    {
        public Rank Rank { get; set; }
        public IEnumerable<SelectListItem> Ranks { get; set; }

        public RankViewModel(Rank rank, IEnumerable Ranks)
        {
            Rank = rank;
            Ranks = new SelectList(Ranks, "Rank", Rank.RankName);
        }
    }*/

    public class GroupViewModel
    {
        [Display(Name = "Rank")]
        public Rank Rank { get; set; }
        public int SelectedRankID { get; set; }
        public IEnumerable<SelectListItem> Ranks { get; set; }
        
    }
}