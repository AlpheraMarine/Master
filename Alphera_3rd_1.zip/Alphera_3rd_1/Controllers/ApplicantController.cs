﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Microsoft.Reporting.WebForms;
using System.IO;
using Alphera_3rd_1.Models;
using Alphera_3rd_1.Helpers;
using System.Net.Mail;

namespace Alphera_3rd_1.Controllers
{
    public class ApplicantController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Applicant
        public ActionResult Index(string option, string statusString, string search)
        {
            int applicantStatusPending = 1; //Pending 1
            int applicantStatusAccepted = 2; //Accepted 2
            int applicantStatusRejected = 3; //Rejected 3

            if (option == "Name")
            {
                return View(db.Applicants.Where(x => x.FirstName == search || search == x.LastName || search == x.FullName ||search == null).ToList());
            }

            else if (option == null)
            {
                ViewBag.Status = (from s in db.ApplicantStatus
                                  where s.ApplicantStatusID == applicantStatusPending || s.ApplicantStatusID == applicantStatusAccepted || s.ApplicantStatusID == applicantStatusRejected
                                  select s.ApplicantStatusName).Distinct();

                if (!string.IsNullOrEmpty(statusString))
                {
                    var status = from r in db.Applicants
                                 orderby r.ApplicantStatus.ApplicantStatusName
                                 where r.ApplicantStatus.ApplicantStatusName == statusString
                                 select r;
                    return View(status.ToList());
                }
            }
            
            //Only show those who are: pending, accepted, rejected
            var applicants = from a in db.Applicants
                              orderby a.ApplicantID
                              where a.ApplicantStatusID == applicantStatusPending || a.ApplicantStatusID == applicantStatusAccepted || a.ApplicantStatusID == applicantStatusRejected
                              select a;
            return View(applicants.ToList());
        }
        //GET: Crew 
        public ActionResult IndexCrew(Applicant applicant, string statusStringCrew, string reportGenerate) //, string applicantName
        {
            //Only Show these values
            #region
            int applicantStatusCrewed = 4; //Crewed
            int applicantStatusWaiting = 5; //Waiting
            int applicantStatusOnBoard = 6; //OnBoard
            int applicantStatusOnVacation = 7; //On Vacation
            int applicantStatusUtility = 8; //Utility Service
            #endregion

            ViewBag.Status = (from s in db.ApplicantStatus
                              where s.ApplicantStatusID == applicantStatusCrewed || s.ApplicantStatusID == applicantStatusWaiting || s.ApplicantStatusID == applicantStatusOnBoard
                              || s.ApplicantStatusID == applicantStatusOnVacation || s.ApplicantStatusID == applicantStatusUtility
                              select s.ApplicantStatusName).Distinct();

            if (!string.IsNullOrEmpty(reportGenerate))
                {
                var status = from r in db.Applicants
                             orderby r.ApplicantStatus.ApplicantStatusName
                             where r.ApplicantStatus.ApplicantStatusID == 4
                             select r;
                }

            //Find by Status
            if (!string.IsNullOrEmpty(statusStringCrew))
            {
                var status = from r in db.Applicants
                             orderby r.ApplicantStatus.ApplicantStatusName
                             where r.ApplicantStatus.ApplicantStatusName == statusStringCrew
                             select r;


                return View(status.ToList());
            }

            //var applicants = db.Applicants.Include(a => a.ApplicantStatus).Include(a => a.Certificate).Include(a => a.License).Include(a => a.Rank);
            //select only applicants who were crewed before
            var applicants = from c in db.Applicants
                             orderby c.ApplicantID
                             where c.ApplicantStatusID == applicantStatusCrewed || c.ApplicantStatusID == applicantStatusWaiting || c.ApplicantStatusID == applicantStatusOnBoard
                             || c.ApplicantStatusID == applicantStatusOnVacation || c.ApplicantStatusID == applicantStatusUtility
                             select c;

            return View(applicants.ToList());
        }

        public ActionResult Report(string id)
        {
            LocalReport lr = new LocalReport();
            string path = Path.Combine(Server.MapPath("~/Reports"), "Applicant.rdlc");
            if (System.IO.File.Exists(path))
            {
                lr.ReportPath = path;
            }
            else
            {
                return View("Index");
            }
            List<Applicant> cm = new List<Applicant>();
            using (ApplicationDbContext dc = new ApplicationDbContext())
            {
                string applicantCrewed = "Pending";
                cm = dc.Applicants.Where(d => d.ApplicantStatus.ApplicantStatusName == applicantCrewed).ToList();
            }
            ReportDataSource rd = new ReportDataSource("Applicant", cm);
            lr.DataSources.Add(rd);
            string reportType = id;
            string mimeType;
            string encoding;
            string fileNameExtension;



            string deviceInfo =

            "<DeviceInfo>" +
            "  <OutputFormat>" + id + "</OutputFormat>" +
            "  <PageWidth>8.5in</PageWidth>" +
            "  <PageHeight>11in</PageHeight>" +
            "  <MarginTop>0.5in</MarginTop>" +
            "  <MarginLeft>1in</MarginLeft>" +
            "  <MarginRight>1in</MarginRight>" +
            "  <MarginBottom>0.5in</MarginBottom>" +
            "</DeviceInfo>";

            Warning[] warnings;
            string[] streams;
            byte[] renderedBytes;

            renderedBytes = lr.Render(
                reportType,
                deviceInfo,
                out mimeType,
                out encoding,
                out fileNameExtension,
                out streams,
                out warnings);
            return File(renderedBytes, mimeType);
        }


        // GET: Applicant/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Applicant applicant = db.Applicants.Find(id);
            if (applicant == null)
            {
                return HttpNotFound();
            }
            return View(applicant);
        }

        // GET: Applicant/Create
        public ActionResult Create()
        {

            ViewBag.ApplicantStatusID = new SelectList(db.ApplicantStatus, "ApplicantStatusID", "ApplicantStatusName");
            ViewBag.CertificateID = new SelectList(db.Certificates, "CertificateID", "Certificates");
            ViewBag.LicenseID = new SelectList(db.Licenses, "LicenseID", "Licenses");
            ViewBag.RankID = new SelectList(db.Ranks, "RankID", "RankCode");
            return View();
        }

        // POST: Applicant/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ApplicantID,RankID,LastName,FirstName,MiddleName,Email,Birthdate,MobileNumber,PresentAddress,CertificateID,LicenseID,SSSNumber,TinNumber,Pagibig,PhilHealth,DateAvailable,ApplicantStatusID")] Applicant applicant)
        {      
            if (ModelState.IsValid)
            { 
                db.Applicants.Add(applicant);


                DateTime bday = DateTime.Parse(Convert.ToString(applicant.Birthdate));
                DateTime today = DateTime.Today;
                int age = today.Year - bday.Year;

                DateTime availableDate = applicant.DateAvailable;

                if (age < 21)
                {
                    //ViewBag.ErrorMessage = "You must be 21 or older to apply." ;
                    TempData["notice"] = "You must be 21 years old or older to apply.";
                    return RedirectToAction("Index");
                }
                else if (availableDate < DateTime.Now)
                {
                    ModelState.AddModelError("DateAvailable", "Your date available must not be a past date.");
                    return RedirectToAction("Index");
                }

                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ApplicantStatusID = new SelectList(db.ApplicantStatus, "ApplicantStatusID", "ApplicantStatusName", applicant.ApplicantStatusID);
            ViewBag.CertificateID = new SelectList(db.Certificates, "CertificateID", "Certificates", applicant.CertificateID);
            ViewBag.LicenseID = new SelectList(db.Licenses, "LicenseID", "Licenses", applicant.LicenseID);
            ViewBag.RankID = new SelectList(db.Ranks, "RankID", "RankCode", applicant.RankID);
            return View(applicant);
        }

        // GET: Applicant/Edit/5
        
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Applicant applicant = db.Applicants.Find(id);
            if (applicant == null)
            {
                return HttpNotFound();
            }
            ViewBag.ApplicantStatusID = new SelectList(db.ApplicantStatus, "ApplicantStatusID", "ApplicantStatusName", applicant.ApplicantStatusID);
            ViewBag.CertificateID = new SelectList(db.Certificates, "CertificateID", "Certificates", applicant.CertificateID);
            ViewBag.LicenseID = new SelectList(db.Licenses, "LicenseID", "Licenses", applicant.LicenseID);
            ViewBag.RankID = new SelectList(db.Ranks, "RankID", "RankCode", applicant.RankID);
            return View(applicant);
        }

        // POST: Applicant/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ApplicantID,RankID,LastName,FirstName,MiddleName,CrewRate,Email,Birthdate,MobileNumber,PresentAddress,CertificateID,LicenseID,SSSNumber,TinNumber,Pagibig,PhilHealth,DateAvailable,ApplicantStatusID")] Applicant applicant)
        {
            if (ModelState.IsValid)
            {
                db.Entry(applicant).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ApplicantStatusID = new SelectList(db.ApplicantStatus, "ApplicantStatusID", "ApplicantStatusName", applicant.ApplicantStatusID);
            ViewBag.CertificateID = new SelectList(db.Certificates, "CertificateID", "Certificates", applicant.CertificateID);
            ViewBag.LicenseID = new SelectList(db.Licenses, "LicenseID", "Licenses", applicant.LicenseID);
            ViewBag.RankID = new SelectList(db.Ranks, "RankID", "RankCode", applicant.RankID);
            return View(applicant);
        }

        // GET: Applicant/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Applicant applicant = db.Applicants.Find(id);
            if (applicant == null)
            {
                return HttpNotFound();
            }
            return View(applicant);
        }

        // POST: Applicant/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Applicant applicant = db.Applicants.Find(id);
            db.Applicants.Remove(applicant);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        /*
        public void EmailReport()
        {
            Attachment a = new Attachment()
            MailSender.SendMail(,,,,,, a);
        }*/
    }
}
