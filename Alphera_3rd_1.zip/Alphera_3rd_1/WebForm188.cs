﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Net.Mail;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net;
using System.Text;
using System.Configuration;


namespace Alphera_3rd_1
{
    public class WebForm188 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SendMail("jason.morales@benilde.edu.ph", "sgt.morales406@gmail.com", "jason.morales@benilde.edu.ph", string.Empty, "Subject", "Message", null);
        }

        private bool SendMail(string mailFrom, string SenderName, string mailTo, string mailCC, string subject, string messageBody, Attachment MailAttachment)
        {
            mailTo = mailTo.Trim(',');
            mailTo = mailTo.Trim(';');

            if (string.IsNullOrEmpty(mailTo))
                return false;
            try
            {
                MailMessage mailMessage = new MailMessage
                {
                    From = new MailAddress(mailFrom, SenderName.Equals(string.Empty) ? mailFrom : SenderName),
                    Subject = subject,
                    Body = messageBody,
                };
                if (null != MailAttachment)
                    mailMessage.Attachments.Add(MailAttachment);

                mailTo = mailTo.Trim();
                mailMessage.To.Add(mailTo);
                if (mailCC.Length > 0)
                    mailMessage.CC.Add(mailCC);
                mailMessage.IsBodyHtml = true;

                new SmtpClient().Send(mailMessage);
                return true;
            }
            catch (SmtpFailedRecipientException sfreError)
            {
                //lblError.Text = sfreError.Message;
                return false;
            }
            catch (SmtpException smtpError)
            {
                //lblError.Text = smtpError.Message;
                return false;
            }
            catch (Exception expError)
            {
                //lblError.Text = expError.Message;
                return false;
            }
        }
    }
}