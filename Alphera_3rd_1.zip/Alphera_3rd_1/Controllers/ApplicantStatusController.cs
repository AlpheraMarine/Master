﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Alphera_3rd_1.Models;

namespace Alphera_3rd_1.Controllers
{
    public class ApplicantStatusController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: ApplicantStatus
        public ActionResult Index()
        {
            return View(db.ApplicantStatus.ToList());
        }

        // GET: ApplicantStatus/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ApplicantStatus applicantStatus = db.ApplicantStatus.Find(id);
            if (applicantStatus == null)
            {
                return HttpNotFound();
            }
            return View(applicantStatus);
        }

        // GET: ApplicantStatus/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ApplicantStatus/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ApplicantStatusID,ApplicantStatusName")] ApplicantStatus applicantStatus)
        {
            if (ModelState.IsValid)
            {
                db.ApplicantStatus.Add(applicantStatus);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(applicantStatus);
        }

        // GET: ApplicantStatus/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ApplicantStatus applicantStatus = db.ApplicantStatus.Find(id);
            if (applicantStatus == null)
            {
                return HttpNotFound();
            }
            return View(applicantStatus);
        }

        // POST: ApplicantStatus/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ApplicantStatusID,ApplicantStatusName")] ApplicantStatus applicantStatus)
        {
            if (ModelState.IsValid)
            {
                db.Entry(applicantStatus).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(applicantStatus);
        }

        // GET: ApplicantStatus/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            ApplicantStatus applicantStatus = db.ApplicantStatus.Find(id);
            if (applicantStatus == null)
            {
                return HttpNotFound();
            }
            return View(applicantStatus);
        }

        // POST: ApplicantStatus/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            ApplicantStatus applicantStatus = db.ApplicantStatus.Find(id);
            db.ApplicantStatus.Remove(applicantStatus);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
