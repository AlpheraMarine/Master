﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

/*
 * IN CASE "RANK.CS -> RANKREQUIREMENTS" IS NOT ENOUGH OR ACCURATE
 * */

namespace Alphera_3rd_1.Models
{
    public class License
    {
        //Primary Key
        public virtual int LicenseID { get; set; }

        [Display(Name = "License")]
        //public virtual string LicenseSN { get; set; }

        public virtual string Licenses { get; set; }
    }

    public class Certificate
    {
        //Primary Key
        public virtual int CertificateID { get; set; }

        [Display(Name = "Certificate")]
        //public virtual string CertificateSN { get; set; }
        public virtual string Certificates { get; set; }
    }

    public class RequirementResult
    {
        public virtual int RequirementResultID { get; set; }
        public virtual string RequirementResultName { get; set; }
    }
}