﻿using Microsoft.Owin;
using Owin;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Alphera_3rd_1.Models;
using System.Security.Claims;

[assembly: OwinStartupAttribute(typeof(Alphera_3rd_1.Startup))]
namespace Alphera_3rd_1
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
            createRoles();
            //Available Roles:
            //Administrator
            //HR
            //Accounting
            //Crew
            //User
        }

        public void createRoles()
        {
            ApplicationDbContext context = new ApplicationDbContext();

            var RoleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(context));
            var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));

            if (!RoleManager.RoleExists("Administrator"))
            {
                //Create Admin Role
                var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
                role.Name = "Administrator";
                RoleManager.Create(role);

                //Create Default Admin
                var user = new ApplicationUser();
                user.UserName = "Jason_Morales";
                user.Email = "Administrator@Alphera.com";
                //Set Password
                string userPWD = "controlADMIN2011!";

                var checkUser = UserManager.Create(user, userPWD);

                if (checkUser.Succeeded)
                {
                    var result = UserManager.AddToRole(user.Id, "Administrator");
                }
            }
            //END ADMIN Creation

            //HR Role
            if (!RoleManager.RoleExists("HR"))
            {
                //Create HR
                var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
                role.Name = "HR";
                RoleManager.Create(role);

                //Default HR
                var user = new ApplicationUser();
                user.UserName = "Raynold_Tibayan";
                user.Email = "HR@Alhpera.com";
                //Password
                string userPWD = "controlADMIN2011!";

                var checkUser = UserManager.Create(user, userPWD);

                //Add User to HR Role
                {
                    var result = UserManager.AddToRole(user.Id, "HR");
                }
            }
            //END HR Role

            //Accounting Role
            if (!RoleManager.RoleExists("Accounting"))
            {
                //Create HR
                var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
                role.Name = "Accounting";
                RoleManager.Create(role);

                //Default HR
                var user = new ApplicationUser();
                user.UserName = "Accounting_Admin";
                user.Email = "AccountingAdmin@Alhpera.com";
                //Password
                string userPWD = "controlADMIN2011!";

                var checkUser = UserManager.Create(user, userPWD);

                //Add User to HR Role
                {
                    var result = UserManager.AddToRole(user.Id, "Accounting");
                }
            }
            //END Accounting Role

            //User Accounts
            if (!RoleManager.RoleExists("User"))
            {
                //User Role
                var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
                role.Name = "User";
                RoleManager.Create(role);
            }
            //END User Accounts

            //Crew Accounts
            if (!RoleManager.RoleExists("Crew"))
            {
                //Crew Role
                var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
                role.Name = "Crew";
                RoleManager.Create(role);
            }
            //END Crew Accounts


        }
    }
}
