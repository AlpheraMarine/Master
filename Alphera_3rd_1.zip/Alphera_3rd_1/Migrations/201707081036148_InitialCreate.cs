namespace Alphera_3rd_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Applicants",
                c => new
                    {
                        ApplicantID = c.Int(nullable: false, identity: true),
                        RankID = c.Int(nullable: false),
                        LastName = c.String(nullable: false),
                        FirstName = c.String(nullable: false),
                        MiddleName = c.String(),
                        CrewRate = c.Decimal(nullable: false, precision: 18, scale: 2),
                        Email = c.String(nullable: false),
                        Birthdate = c.String(nullable: false),
                        MobileNumber = c.String(nullable: false),
                        PresentAddress = c.String(),
                        CertificateID = c.Int(nullable: false),
                        LicenseID = c.Int(nullable: false),
                        SSSNumber = c.String(),
                        TinNumber = c.String(),
                        Pagibig = c.String(),
                        PhilHealth = c.String(),
                        DateAvailable = c.String(nullable: false),
                        ApplicantStatusID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.ApplicantID)
                .ForeignKey("dbo.ApplicantStatus", t => t.ApplicantStatusID, cascadeDelete: true)
                .ForeignKey("dbo.Certificates", t => t.CertificateID, cascadeDelete: true)
                .ForeignKey("dbo.Licenses", t => t.LicenseID, cascadeDelete: true)
                .ForeignKey("dbo.Ranks", t => t.RankID, cascadeDelete: true)
                .Index(t => t.RankID)
                .Index(t => t.CertificateID)
                .Index(t => t.LicenseID)
                .Index(t => t.ApplicantStatusID);
            
            CreateTable(
                "dbo.ApplicantStatus",
                c => new
                    {
                        ApplicantStatusID = c.Int(nullable: false, identity: true),
                        ApplicantStatusName = c.String(),
                    })
                .PrimaryKey(t => t.ApplicantStatusID);
            
            CreateTable(
                "dbo.Certificates",
                c => new
                    {
                        CertificateID = c.Int(nullable: false, identity: true),
                        Certificates = c.String(),
                    })
                .PrimaryKey(t => t.CertificateID);
            
            CreateTable(
                "dbo.Licenses",
                c => new
                    {
                        LicenseID = c.Int(nullable: false, identity: true),
                        Licenses = c.String(),
                    })
                .PrimaryKey(t => t.LicenseID);
            
            CreateTable(
                "dbo.Ranks",
                c => new
                    {
                        RankID = c.Int(nullable: false, identity: true),
                        RankCode = c.String(nullable: false),
                        RankName = c.String(nullable: false),
                        BasicRankPay = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.RankID);
            
            CreateTable(
                "dbo.CrewStatus",
                c => new
                    {
                        CrewStatusID = c.Int(nullable: false, identity: true),
                        CrewStatusName = c.String(),
                    })
                .PrimaryKey(t => t.CrewStatusID);
            
            CreateTable(
                "dbo.Deployments",
                c => new
                    {
                        DeploymentID = c.Int(nullable: false, identity: true),
                        ApplicantID = c.Int(nullable: false),
                        VesselID = c.Int(nullable: false),
                        SignOn = c.String(),
                        SignOff = c.String(),
                        Remarks = c.String(),
                        DeploymentStaus_DeploymentStatusID = c.Int(),
                    })
                .PrimaryKey(t => t.DeploymentID)
                .ForeignKey("dbo.Applicants", t => t.ApplicantID, cascadeDelete: true)
                .ForeignKey("dbo.DeploymentStatus", t => t.DeploymentStaus_DeploymentStatusID)
                .ForeignKey("dbo.Vessels", t => t.VesselID, cascadeDelete: true)
                .Index(t => t.ApplicantID)
                .Index(t => t.VesselID)
                .Index(t => t.DeploymentStaus_DeploymentStatusID);
            
            CreateTable(
                "dbo.DeploymentStatus",
                c => new
                    {
                        DeploymentStatusID = c.Int(nullable: false, identity: true),
                        DeploymentStatusName = c.String(),
                    })
                .PrimaryKey(t => t.DeploymentStatusID);
            
            CreateTable(
                "dbo.Vessels",
                c => new
                    {
                        VesselID = c.Int(nullable: false, identity: true),
                        VesselName = c.String(nullable: false),
                        PortID = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.VesselID)
                .ForeignKey("dbo.Ports", t => t.PortID, cascadeDelete: true)
                .Index(t => t.PortID);
            
            CreateTable(
                "dbo.Ports",
                c => new
                    {
                        PortID = c.Int(nullable: false, identity: true),
                        PortName = c.String(),
                        Country = c.String(),
                    })
                .PrimaryKey(t => t.PortID);
            
            CreateTable(
                "dbo.InterviewResultStatus",
                c => new
                    {
                        InterviewResultStatusID = c.Int(nullable: false, identity: true),
                        InterviewResultStatusName = c.String(),
                    })
                .PrimaryKey(t => t.InterviewResultStatusID);
            
            CreateTable(
                "dbo.Interviews",
                c => new
                    {
                        InterviewID = c.Int(nullable: false, identity: true),
                        ApplicantID = c.Int(nullable: false),
                        InterviewTitle = c.String(),
                        InterviewDate = c.DateTime(nullable: false),
                        InterviewTime = c.DateTime(nullable: false),
                        InterviewResultStatusID = c.Int(nullable: false),
                        InterviewRemark = c.String(),
                    })
                .PrimaryKey(t => t.InterviewID)
                .ForeignKey("dbo.Applicants", t => t.ApplicantID, cascadeDelete: true)
                .ForeignKey("dbo.InterviewResultStatus", t => t.InterviewResultStatusID, cascadeDelete: true)
                .Index(t => t.ApplicantID)
                .Index(t => t.InterviewResultStatusID);
            
            CreateTable(
                "dbo.Payrolls",
                c => new
                    {
                        PayrollID = c.Int(nullable: false, identity: true),
                        ApplicantID = c.Int(nullable: false),
                        DateAttended = c.DateTime(nullable: false),
                        Date = c.DateTime(nullable: false),
                        TimeIn = c.DateTime(),
                        TimeOut = c.DateTime(),
                        GrossPay = c.Decimal(nullable: false, precision: 18, scale: 2),
                    })
                .PrimaryKey(t => t.PayrollID)
                .ForeignKey("dbo.Applicants", t => t.ApplicantID, cascadeDelete: true)
                .Index(t => t.ApplicantID);
            
            CreateTable(
                "dbo.AspNetRoles",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        Name = c.String(nullable: false, maxLength: 256),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.Name, unique: true, name: "RoleNameIndex");
            
            CreateTable(
                "dbo.AspNetUserRoles",
                c => new
                    {
                        UserId = c.String(nullable: false, maxLength: 128),
                        RoleId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.UserId, t.RoleId })
                .ForeignKey("dbo.AspNetRoles", t => t.RoleId, cascadeDelete: true)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId)
                .Index(t => t.RoleId);
            
            CreateTable(
                "dbo.AspNetUsers",
                c => new
                    {
                        Id = c.String(nullable: false, maxLength: 128),
                        Email = c.String(maxLength: 256),
                        EmailConfirmed = c.Boolean(nullable: false),
                        PasswordHash = c.String(),
                        SecurityStamp = c.String(),
                        PhoneNumber = c.String(),
                        PhoneNumberConfirmed = c.Boolean(nullable: false),
                        TwoFactorEnabled = c.Boolean(nullable: false),
                        LockoutEndDateUtc = c.DateTime(),
                        LockoutEnabled = c.Boolean(nullable: false),
                        AccessFailedCount = c.Int(nullable: false),
                        UserName = c.String(nullable: false, maxLength: 256),
                    })
                .PrimaryKey(t => t.Id)
                .Index(t => t.UserName, unique: true, name: "UserNameIndex");
            
            CreateTable(
                "dbo.AspNetUserClaims",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        UserId = c.String(nullable: false, maxLength: 128),
                        ClaimType = c.String(),
                        ClaimValue = c.String(),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
            CreateTable(
                "dbo.AspNetUserLogins",
                c => new
                    {
                        LoginProvider = c.String(nullable: false, maxLength: 128),
                        ProviderKey = c.String(nullable: false, maxLength: 128),
                        UserId = c.String(nullable: false, maxLength: 128),
                    })
                .PrimaryKey(t => new { t.LoginProvider, t.ProviderKey, t.UserId })
                .ForeignKey("dbo.AspNetUsers", t => t.UserId, cascadeDelete: true)
                .Index(t => t.UserId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.AspNetUserRoles", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserLogins", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserClaims", "UserId", "dbo.AspNetUsers");
            DropForeignKey("dbo.AspNetUserRoles", "RoleId", "dbo.AspNetRoles");
            DropForeignKey("dbo.Payrolls", "ApplicantID", "dbo.Applicants");
            DropForeignKey("dbo.Interviews", "InterviewResultStatusID", "dbo.InterviewResultStatus");
            DropForeignKey("dbo.Interviews", "ApplicantID", "dbo.Applicants");
            DropForeignKey("dbo.Deployments", "VesselID", "dbo.Vessels");
            DropForeignKey("dbo.Vessels", "PortID", "dbo.Ports");
            DropForeignKey("dbo.Deployments", "DeploymentStaus_DeploymentStatusID", "dbo.DeploymentStatus");
            DropForeignKey("dbo.Deployments", "ApplicantID", "dbo.Applicants");
            DropForeignKey("dbo.Applicants", "RankID", "dbo.Ranks");
            DropForeignKey("dbo.Applicants", "LicenseID", "dbo.Licenses");
            DropForeignKey("dbo.Applicants", "CertificateID", "dbo.Certificates");
            DropForeignKey("dbo.Applicants", "ApplicantStatusID", "dbo.ApplicantStatus");
            DropIndex("dbo.AspNetUserLogins", new[] { "UserId" });
            DropIndex("dbo.AspNetUserClaims", new[] { "UserId" });
            DropIndex("dbo.AspNetUsers", "UserNameIndex");
            DropIndex("dbo.AspNetUserRoles", new[] { "RoleId" });
            DropIndex("dbo.AspNetUserRoles", new[] { "UserId" });
            DropIndex("dbo.AspNetRoles", "RoleNameIndex");
            DropIndex("dbo.Payrolls", new[] { "ApplicantID" });
            DropIndex("dbo.Interviews", new[] { "InterviewResultStatusID" });
            DropIndex("dbo.Interviews", new[] { "ApplicantID" });
            DropIndex("dbo.Vessels", new[] { "PortID" });
            DropIndex("dbo.Deployments", new[] { "DeploymentStaus_DeploymentStatusID" });
            DropIndex("dbo.Deployments", new[] { "VesselID" });
            DropIndex("dbo.Deployments", new[] { "ApplicantID" });
            DropIndex("dbo.Applicants", new[] { "ApplicantStatusID" });
            DropIndex("dbo.Applicants", new[] { "LicenseID" });
            DropIndex("dbo.Applicants", new[] { "CertificateID" });
            DropIndex("dbo.Applicants", new[] { "RankID" });
            DropTable("dbo.AspNetUserLogins");
            DropTable("dbo.AspNetUserClaims");
            DropTable("dbo.AspNetUsers");
            DropTable("dbo.AspNetUserRoles");
            DropTable("dbo.AspNetRoles");
            DropTable("dbo.Payrolls");
            DropTable("dbo.Interviews");
            DropTable("dbo.InterviewResultStatus");
            DropTable("dbo.Ports");
            DropTable("dbo.Vessels");
            DropTable("dbo.DeploymentStatus");
            DropTable("dbo.Deployments");
            DropTable("dbo.CrewStatus");
            DropTable("dbo.Ranks");
            DropTable("dbo.Licenses");
            DropTable("dbo.Certificates");
            DropTable("dbo.ApplicantStatus");
            DropTable("dbo.Applicants");
        }
    }
}
