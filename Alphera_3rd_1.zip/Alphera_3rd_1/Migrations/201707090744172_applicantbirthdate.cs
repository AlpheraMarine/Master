namespace Alphera_3rd_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class applicantbirthdate : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Applicants", "Birthdate", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Applicants", "Birthdate", c => c.String(nullable: false));
        }
    }
}
