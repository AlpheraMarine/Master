namespace Alphera_3rd_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class applicantavailabledate : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Applicants", "DateAvailable", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Applicants", "DateAvailable", c => c.String(nullable: false));
        }
    }
}
