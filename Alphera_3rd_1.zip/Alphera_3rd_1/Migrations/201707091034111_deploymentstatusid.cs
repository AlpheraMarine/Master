namespace Alphera_3rd_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class deploymentstatusid : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Deployments", "DeploymentStatus_DeploymentStatusID", "dbo.DeploymentStatus");
            DropIndex("dbo.Deployments", new[] { "DeploymentStatus_DeploymentStatusID" });
            RenameColumn(table: "dbo.Deployments", name: "DeploymentStatus_DeploymentStatusID", newName: "DeploymentStatusID");
            AlterColumn("dbo.Deployments", "DeploymentStatusID", c => c.Int(nullable: false));
            CreateIndex("dbo.Deployments", "DeploymentStatusID");
            AddForeignKey("dbo.Deployments", "DeploymentStatusID", "dbo.DeploymentStatus", "DeploymentStatusID", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Deployments", "DeploymentStatusID", "dbo.DeploymentStatus");
            DropIndex("dbo.Deployments", new[] { "DeploymentStatusID" });
            AlterColumn("dbo.Deployments", "DeploymentStatusID", c => c.Int());
            RenameColumn(table: "dbo.Deployments", name: "DeploymentStatusID", newName: "DeploymentStatus_DeploymentStatusID");
            CreateIndex("dbo.Deployments", "DeploymentStatus_DeploymentStatusID");
            AddForeignKey("dbo.Deployments", "DeploymentStatus_DeploymentStatusID", "dbo.DeploymentStatus", "DeploymentStatusID");
        }
    }
}
