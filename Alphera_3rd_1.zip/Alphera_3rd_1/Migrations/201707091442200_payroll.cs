namespace Alphera_3rd_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class payroll : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.PayrollStatus",
                c => new
                    {
                        PayrollStatusID = c.Int(nullable: false, identity: true),
                        PayrollStatusName = c.String(),
                    })
                .PrimaryKey(t => t.PayrollStatusID);
            
            AddColumn("dbo.Payrolls", "PayrollStatusID", c => c.Int(nullable: false));
            CreateIndex("dbo.Payrolls", "PayrollStatusID");
            AddForeignKey("dbo.Payrolls", "PayrollStatusID", "dbo.PayrollStatus", "PayrollStatusID", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Payrolls", "PayrollStatusID", "dbo.PayrollStatus");
            DropIndex("dbo.Payrolls", new[] { "PayrollStatusID" });
            DropColumn("dbo.Payrolls", "PayrollStatusID");
            DropTable("dbo.PayrollStatus");
        }
    }
}
