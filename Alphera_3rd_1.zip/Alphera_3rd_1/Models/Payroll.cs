﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Alphera_3rd_1.Models
{
    public class Payroll
    {
        public virtual int PayrollID { get; set; }

        [Display(Name = "Crew")]
        public virtual int ApplicantID { get; set; }
        public virtual Applicant Applicant { get; set; }

        [Display(Name = "Date Attended")]
        [DataType(DataType.Date)]
        public virtual DateTime DateAttended { get; set; }

        [Display(Name = "Date Inputed")]
        [DataType(DataType.Date)]
        public virtual DateTime Date { get; set; }

        [Display(Name = "Time In")]
        [DataType(DataType.Time)]
        public virtual DateTime TimeIn { get; set; }

        [Display(Name = "Time Out")]
        [DataType(DataType.Time)]
        public virtual DateTime TimeOut { get; set; }

        //public virtual int PayrollStatusID { get; set; }
        //public virtual PayrollStatus PayrollStatus { get; set; }

        [Display(Name = "Pay(Php)")]
        public virtual decimal GrossPay { get; set; }
    }

    public class PayrollStatus
    {
        public virtual int PayrollStatusID { get; set; }
        [Display(Name = "Status")]
        public virtual string PayrollStatusName { get; set; }
    }

    //Deductions
    public class Tax
    {
        //Primary Key
        public virtual int TaxID { get; set; }

        public virtual int PayrollID { get; set; }
        public virtual decimal TaxPercentage { get; set; }

        public virtual decimal TaxDeductionAmount { get; set; }


        public virtual Payroll Payroll { get; set; }
    }
    //public class SSS
    //{
    //    //Primary Key
    //    public virtual int SSSID { get; set; }

    //    public virtual int PayrollID { get; set; }

    //    public virtual decimal SSSPercentage { get; set; }
    //    public virtual decimal SSSDeductionAmount { get; set; }
    //    public virtual Payroll Payroll { get; set; }
    //}

    //public class Pagibig
    //{
    //    //Primary Key
    //    public virtual int PagibigID { get; set; }
    //    public virtual int PayrollID { get; set; }
    //    public virtual decimal PagibigPercentage { get; set; }
    //    public virtual decimal PagibigDeductionAmount { get; set; }
    //    public virtual Payroll Payroll { get; set; }
    //}

    //public class Philhealth
    //{
    //    //Primary Key
    //    public virtual int PhilhealthID { get; set; }
    //    public virtual int PayrollID { get; set; }
    //    public virtual decimal PhilHealthPercentage { get; set; }
    //    public virtual decimal PhilhealthDeduction_Amount { get; set; }
    //    public virtual Payroll Payroll { get; set; }
    //}

    //Calculator
    public class Deduction
    {
        public virtual int DeductionID { get; set; }
        public virtual int TaxID { get; set; }
        //public virtual int SSSID { get; set; }
        //public virtual int PagibigID { get; set; }
        //public virtual int PhilhealthID { get; set; }
        public virtual decimal TotalDeduction { get; set; }

        //public virtual SSS SSS { get; set; }
        //public virtual Pagibig Pagibig { get; set; }
        //public virtual Philhealth Philhealth { get; set; }
        public virtual Tax Tax { get; set; }
    }
    //END DEDUCTIONS

}