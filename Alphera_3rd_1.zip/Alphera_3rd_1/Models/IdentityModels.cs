﻿using System.Data.Entity;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;

namespace Alphera_3rd_1.Models
{
    // You can add profile data for the user by adding more properties to your ApplicationUser class, please visit http://go.microsoft.com/fwlink/?LinkID=317594 to learn more.
    public class ApplicationUser : IdentityUser
    {
        public async Task<ClaimsIdentity> GenerateUserIdentityAsync(UserManager<ApplicationUser> manager)
        {
            // Note the authenticationType must match the one defined in CookieAuthenticationOptions.AuthenticationType
            var userIdentity = await manager.CreateIdentityAsync(this, DefaultAuthenticationTypes.ApplicationCookie);
            // Add custom user claims here
            return userIdentity;
        }
    }

    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        public static ApplicationDbContext Create()
        {
            return new ApplicationDbContext();
        }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.ApplicantStatus> ApplicantStatus { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.Applicant> Applicants { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.Certificate> Certificates { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.License> Licenses { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.Rank> Ranks { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.Port> Ports { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.Vessel> Vessels { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.CrewStatus> CrewStatus { get; set; }

        //public System.Data.Entity.DbSet<Alphera_3rd_1.Models.Crew> Crews { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.Interview> Interviews { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.InterviewResultStatus> InterviewResultStatus { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.Deployment> Deployments { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.Payroll> Payrolls { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.DeploymentStatus> DeploymentStatus { get; set; }

        public System.Data.Entity.DbSet<Alphera_3rd_1.Models.PayrollStatus> PayrollStatus { get; set; }
    }
}