﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Net.Mail;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net;
using System.Text;
using System.Configuration;
using Microsoft.Reporting.Webforms;
using Alphera_3rd_1.Models;

namespace Alphera_3rd_1.Helpers
{
    public class GenerateReport
    {
        

    }
}