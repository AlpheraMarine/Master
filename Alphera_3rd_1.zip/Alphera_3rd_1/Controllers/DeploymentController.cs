﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using Microsoft.Reporting.WebForms;
using System.IO;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Alphera_3rd_1.Models;

namespace Alphera_3rd_1.Controllers
{
    public class DeploymentController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();
        int deploymentStatusStringOnBoard = 1;
        int deploymentStatusStringFinished = 2;
        
        // GET: Deployment
        public ActionResult Index(string statusString)
        {


            ViewBag.Status = (from d in db.DeploymentStatus
                              where d.DeploymentStatusID == deploymentStatusStringOnBoard || d.DeploymentStatusID == deploymentStatusStringFinished
                              select d.DeploymentStatusName).Distinct();
            //search
            if (!string.IsNullOrEmpty(statusString))
            {
                
                var status = from e in db.Deployments
                             orderby e.DeploymentStatus.DeploymentStatusName
                             where e.DeploymentStatus.DeploymentStatusName == statusString
                             select e;
                return View(status.ToList());
            }
            //var deployments = db.Deployments.Include(d => d.Applicant).Include(d => d.Vessel);
            var deployments = from p in db.Deployments
                              orderby p.DeploymentID
                              where p.DeploymentStatusID == deploymentStatusStringOnBoard || p.DeploymentStatusID == deploymentStatusStringFinished
                              select p;
            

            return View(deployments.ToList());



        }

        // GET: Deployment/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Deployment deployment = db.Deployments.Find(id);
            if (deployment == null)
            {
                return HttpNotFound();
            }
            return View(deployment);
        }

        public ActionResult Report(string id)
        {
            
            LocalReport lr = new LocalReport();
            string path = Path.Combine(Server.MapPath("~/Reports"), "Deployment.rdlc");
            if (System.IO.File.Exists(path))
            {
                lr.ReportPath = path;
            }
            else
            {
                return View("Index");
            }
            List<Deployment> cm = new List<Deployment>();
            using (ApplicationDbContext dc = new ApplicationDbContext())
            {
                string deploymentStatus = "Currently Deployed";
                cm = dc.Deployments.Where(d => d.DeploymentStatus.DeploymentStatusName == deploymentStatus).ToList();
            


            ReportDataSource rd = new ReportDataSource("Deployment", cm);
                lr.DataSources.Add(rd);
                string reportType = id;
                string mimeType;
                string encoding;
                string fileNameExtension;



                string deviceInfo =

                "<DeviceInfo>" +
                "  <OutputFormat>" + id + "</OutputFormat>" +
                "  <PageWidth>8.5in</PageWidth>" +
                "  <PageHeight>11in</PageHeight>" +
                "  <MarginTop>0.5in</MarginTop>" +
                "  <MarginLeft>1in</MarginLeft>" +
                "  <MarginRight>1in</MarginRight>" +
                "  <MarginBottom>0.5in</MarginBottom>" +
                "</DeviceInfo>";

                Warning[] warnings;
                string[] streams;
                byte[] renderedBytes;

                renderedBytes = lr.Render(
                    reportType,
                    deviceInfo,
                    out mimeType,
                    out encoding,
                    out fileNameExtension,
                    out streams,
                    out warnings);


                return File(renderedBytes, mimeType);
            }
        }

        // GET: Deployment/Create
        public ActionResult Create()
        {
            string applicantStatus = "Crewed"; //comment when string below is accepted
            //string applicantStatus = "Waiting"; //When principal confirms them

            ViewBag.ApplicantID = new SelectList(db.Applicants.Where(a => a.ApplicantStatus.ApplicantStatusName == applicantStatus), "ApplicantID", "FullName");
            ViewBag.DeploymentStatusID = new SelectList(db.DeploymentStatus, "DeploymentStatusID", "DeploymentStatusName");
            ViewBag.VesselID = new SelectList(db.Vessels, "VesselID", "VesselName");
            return View();
        }

        // POST: Deployment/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "DeploymentID,ApplicantID,VesselID,SignOn,SignOff,Remarks,DeploymentStatusID")] Deployment deployment)
        {
            Applicant applicant = new Applicant();
            int applicantID = deployment.ApplicantID;
            int deploymentStatus = deployment.DeploymentStatusID;


            applicant = (from a in db.Applicants
                         where a.ApplicantID == applicantID
                         select a).First();
            // Past Constraint: dateInput <= DateNow
            // Future Constraint Dateinput >= DateNow
            if (ModelState.IsValid)
            {
                db.Deployments.Add(deployment);
                
                //If crew will disembark before embarking //REJECTED
                if (deployment.SignOff <= deployment.SignOn || deployment.SignOn < DateTime.Now)
                {
                    TempData["notice"] = "Invalid deployment schedule. Sign off date should not be earlier than Sign On Date.";
                    return RedirectToAction("Create");
                }
                //if crew will be deployed today //REJECTED
                else if (deployment.SignOn == DateTime.Now)
                {
                    TempData["notice"] = "Crew can not be deployed on short notice";
                    return RedirectToAction("Create");
                }
                //if crew will disembark after embarking //ACCEPTED
                else if (deployment.SignOn < deployment.SignOff && deployment.SignOn > DateTime.Now)
                {
                    deployment.DeploymentStatusID = 1;
                    applicant.ApplicantStatusID = 6;
                }

                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ApplicantID = new SelectList(db.Applicants, "ApplicantID", "FullName", deployment.ApplicantID);
            ViewBag.DeploymentStatusID = new SelectList(db.DeploymentStatus, "DeploymentStatusID", "DeploymentStatusName");
            ViewBag.VesselID = new SelectList(db.Vessels, "VesselID", "VesselName", deployment.VesselID);
            return View(deployment);
        }

        // GET: Deployment/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Deployment deployment = db.Deployments.Find(id);
            if (deployment == null)
            {
                return HttpNotFound();
            }
            ViewBag.ApplicantID = new SelectList(db.Applicants, "ApplicantID", "FullName", deployment.ApplicantID);
            ViewBag.VesselID = new SelectList(db.Vessels, "VesselID", "VesselName", deployment.VesselID);
            return View(deployment);
        }

        // POST: Deployment/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "DeploymentID,ApplicantID,VesselID,SignOn,SignOff,Remarks,DeploymentStatusID")] Deployment deployment)
        {
            Applicant applicant = new Applicant();
            int applicantID = deployment.ApplicantID;
            int deploymentStatus = deployment.DeploymentStatusID;




            if (ModelState.IsValid)
            {
                db.Entry(deployment).State = EntityState.Modified;

                if (deployment.SignOff <= deployment.SignOn || deployment.SignOn < DateTime.Now)
                {
                    TempData["notice"] = "Invalid deployment schedule. Sign off date should not be earlier than Sign On Date.";
                    return RedirectToAction("Create");
                }
                //if crew will be deployed today //REJECTED
                else if (deployment.SignOn == DateTime.Now)
                {
                    TempData["notice"] = "Crew can not be deployed on short notice";
                    return RedirectToAction("Create");
                }
                //if crew will disembark after embarking //ACCEPTED
                else if (deployment.SignOn < deployment.SignOff && deployment.SignOn > DateTime.Now)
                {
                    deployment.DeploymentStatusID = 1;
                    //deployment.Applicant.ApplicantStatusID = 7;
                    applicant.ApplicantStatusID = 6;
                }

                db.SaveChanges();


                return RedirectToAction("Index");
            }
            ViewBag.ApplicantID = new SelectList(db.Applicants, "ApplicantID", "FullName", deployment.ApplicantID);
            ViewBag.DeploymentStatusID = new SelectList(db.DeploymentStatus, "DeploymentStatusID", "DeploymentStatusName", deployment.DeploymentStatusID);
            ViewBag.VesselID = new SelectList(db.Vessels, "VesselID", "VesselName", deployment.VesselID);
            return View(deployment);
        }

        // GET: Deployment/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Deployment deployment = db.Deployments.Find(id);
            if (deployment == null)
            {
                return HttpNotFound();
            }
            return View(deployment);
        }

        // POST: Deployment/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Deployment deployment = db.Deployments.Find(id);
            db.Deployments.Remove(deployment);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
