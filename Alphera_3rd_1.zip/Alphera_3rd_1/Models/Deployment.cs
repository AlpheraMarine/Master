﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Alphera_3rd_1.Models
{
    public class Deployment
    {
        //Primary Key
        public virtual int DeploymentID { get; set; }

        //FK
        [Display(Name = "Crew")]
        public virtual int ApplicantID { get; set; }
        public virtual Applicant Applicant { get; set; }

        //FK - Current Vessel / Blank if not on-board
        [Display(Name = "Current Vessel")]
        public virtual int VesselID { get; set; }
        public virtual Vessel Vessel { get; set; }

        //Sign On Date / Boarding Date
        [DataType(DataType.Date)]
        [Display(Name = "Sign On")]
        public virtual DateTime SignOn { get; set; }

        //Sign Off Date / Disembark Date
        [DataType(DataType.Date)]
        [Display(Name = "Sign Off")]
        public virtual DateTime SignOff { get; set; }

        //Remarks
        [Display(Name = "Remarks")]
        public virtual string Remarks { get; set; }

        public virtual int DeploymentStatusID { get; set; }

        public virtual DeploymentStatus DeploymentStatus { get; set; }
    }

    public class DeploymentStatus
    {
        //PK
        public virtual int DeploymentStatusID { get; set; }

        [Display(Name = "Deployment Status")]
        public virtual string DeploymentStatusName { get; set; }
    }
}