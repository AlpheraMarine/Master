﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;

namespace Alphera_3rd_1.Controllers
{
    public class SubmitApplicationController : Controller
    {/*
        // GET: SubmitApplication
        public ActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// Send Mail with Gmail
        /// </summary>
        // <param name="objModelMail">MailModel Object, keeps all properties</param>
        // <param name="fileUploader">Selected file data, example-filename,content,content type(file type- .txt,.png etc.),length etc.</param>
        /// <returns></returns>

        [HttpPost]
        public ActionResult Index(Alphera_3rd_1.Models.Application objModelMail, 
            HttpPostedFileBase fileUploader)
        {
            if (ModelState.IsValid)
            {
                string from = "jason.morales@benilde.edu.ph";
                using (MailMessage mail = new MailMessage(from, objModelMail.ApplicationTo))
                {
                    mail.Subject = objModelMail.ApplicationSubject;
                    mail.Body = objModelMail.LastName;
                    if (fileUploader != null)
                    {
                        string fileName = Path.GetFileName(fileUploader.FileName);
                        mail.Attachments.Add(new Attachment(fileUploader.InputStream, fileName));
                    }
                    mail.IsBodyHtml = false;
                    SmtpClient smtp = new SmtpClient();
                    smtp.Host = "smtp.gmail.com";
                    smtp.EnableSsl = true;
                    NetworkCredential networkCredential = new NetworkCredential(from, "Messierbk1742");
                    smtp.UseDefaultCredentials = true;
                    smtp.Port = 587;
                    smtp.Send(mail);
                    ViewBag.Message = "Your application has been sent";
                    return View("Index", objModelMail);
                }
            }
            else
            {
                return View();
            }
            

            
        }
        //END File Uploader
        */
    }
}