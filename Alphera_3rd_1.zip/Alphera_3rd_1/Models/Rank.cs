﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

/* Process Flow
 * 1. APPLICANT must be able to select a RANK from a dropdown list
 * 
 * 2. Depending on RANK, APPLICANT will have a set of REQUIREMENTS to COMPLY FOR
 * 
 * 3. RANK PROCESS
 *      3.A. IF APPLICANT is ACCEPTED and ADDED to CREW
 *          3.A.1. Positions Available will deduct 1 slot. 
 *              i.e. IF slots available is 5, then 1 APPLICANT passed interview
 *                  THEN 5-1= 4 (slots available - 1 = updated slots available)
 *      3.B. IF APPLICANT is REJECTED THEN no deduction to SLOTS AVAILABLE
 * 
 * 4. ADMIN RIGHTS
 *      4.A ADMIN can add new ranks and requirements to each rank
 *      4.B ADMIN can edit available slots for ranks.
 *          4.B.1. If available slots for ranks is 0, APPLICANT can still send, but pending only until needed
 *          4.B.2. RANK REQUIREMENTS or DOCUMENTS MUST BE FILLED before sending application
 *              4.B.2.1. NO NEED FOR REQUIREMENT SERIAL NUMBER -> CHECKBOX or CHECKLIST OPTIONS ask if AVAILABLE
 *              
 * */

namespace Alphera_3rd_1.Models
{
    public class Rank
    {
        //Primary Key
        public virtual int RankID { get; set; }

        //Rank Code (i.e. MTR)
        [Required(ErrorMessage = "Rank Code required.")]
        [Display(Name = "Code")]
        public virtual string RankCode { get; set; }
        //Rank Name (i.e. Master)
        [Required(ErrorMessage = "Rank Name required.")]
        [Display(Name = "Rank")]
        public virtual string RankName { get; set; }

        //Basic Pay
        [Required(ErrorMessage = "Please input basic pay.")]
        [Display(Name = "Basic Pay")]
        public virtual int BasicRankPay { get; set; }

    }

}