﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Alphera_3rd_1.Controllers
{
    public class EndDeploymentController : Controller
    {
        // GET: EndDeployment
        public ActionResult Index()
        {
            return View();
        }
    }
}