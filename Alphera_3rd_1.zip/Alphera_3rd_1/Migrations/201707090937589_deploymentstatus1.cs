namespace Alphera_3rd_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class deploymentstatus1 : DbMigration
    {
        public override void Up()
        {
            RenameColumn(table: "dbo.Deployments", name: "DeploymentStaus_DeploymentStatusID", newName: "DeploymentStatus_DeploymentStatusID");
            RenameIndex(table: "dbo.Deployments", name: "IX_DeploymentStaus_DeploymentStatusID", newName: "IX_DeploymentStatus_DeploymentStatusID");
        }
        
        public override void Down()
        {
            RenameIndex(table: "dbo.Deployments", name: "IX_DeploymentStatus_DeploymentStatusID", newName: "IX_DeploymentStaus_DeploymentStatusID");
            RenameColumn(table: "dbo.Deployments", name: "DeploymentStatus_DeploymentStatusID", newName: "DeploymentStaus_DeploymentStatusID");
        }
    }
}
