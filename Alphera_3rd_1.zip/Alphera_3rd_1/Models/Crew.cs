﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc;

/*
 * Process flow for Recruitment
 * 1. APPLICANT will FILL UP REQUIRED FORMS for notification from ADMIN
 * 2. APPLICANT can ONLY VIEW a dashboard that will show an announcement
 *      i.e. 
 *          "Your application is still being processed.
 *           Please wait for notification from this website.
 *           Please prepare the necessary documents/requirements for your interview:
 *           Doc#1
 *           Doc#2
 *           Doc#3
 *           ..."
 * 3. ADMIN will set INTERVIEW DATE of the APPLICANT.
 * 4. APPLICANT can VIEW INTERVIEW DATE UPDATE on dashboard from Step 2.
 * 5. ADMIN will change APPLICANT STATUS depending on interview
 *      i.e.
 *          Accepted or Rejected
 *          
 * 6. IF ACCEPTED, APPLICANT will automatically be moved to CREW.
 *      i.e. after ADMIN set status to "Accepted Applicant"
 *          system will take "Accepted Applicant" and other data
 *          and add selected Applicant to Crew. +(AUTOMATED)+
 *  
 *  Status needs to be inputted manually
 *      Accepted, Rejected, Pending
 *      On-Board, On-Vacation, Active, Ready, Inactive
 * -------------------------------------------------------------------------------------
 * CREW Process Flow
 * 1. ADMIN will ASSIGN "ACTIVE" CREW to VESSELS
 * 2. Once assigned, ADMIN will Select Sign-On Date for crew
 * 3. CREW will need to attend MEDICAL CHECK UP 
 * 4. MEDICAL
 *      4.a. IF MEDICAL is APPROVED
 *          then CREW will be set to Ready
 *      4.b IF MEDICAL is NOT APPROVED
 *          then CREW will be set to Inactive
 *    
 * 5. Ready CREW will be deployed on Sign-On Date and on the date itself,
 *      STATUS will be changed to On-Board +(AUTOMATED)+
 * --------------------------------------------------------------------------------------
 * CONSTRAINTS:
 *      Crew SIGN ON CANNOT be at a later date than SIGN OFF
 *      Crew SIGN OFF CANNOT be at an earlier date than SIGN ON
 *      Crew CANNOT BE SIGNED ON WITHOUT SIGNING OFF at a CURRENT SIGN ON
*/

namespace Alphera_3rd_1.Models
{
    /*
    public class Crew
    {
        //Primary Key
        //[ForeignKey("Applicant")]
        public virtual int CrewID { get; set; }

        //Foreign Key
        public virtual int ApplicantID { get; set; }
        

        [Display(Name = "Rate (per minute)")]
        public virtual decimal CrewRate { get; set; }

        //public virtual decimal PayMin { get; set; }
        //public virtual ICollection<Payroll> Payrolls { get; set; }

        //FK- Status
        //Waiting, On-Board, On-Vacation, Utility Service
        [Display(Name = "Status")]
        public virtual int CrewStatusID { get; set; }
        public virtual  CrewStatus CrewStatus { get; set; }

        public virtual Applicant Applicant { get; set; }
    }
    */
    public class Applicant
    {
        //Primary Key
        public virtual int ApplicantID { get; set; }

        //public Applicant() { }

        //FK - Rank
        public virtual int RankID { get; set; }
        public virtual  Rank Rank { get; set; }

        //Name
        [Required(ErrorMessage = "Last Name required.")]
        [Display(Name = "Last Name")]
        public virtual string LastName { get; set; }

        [Required(ErrorMessage = "First Name required.")]
        [Display(Name = "First Name")]
        public virtual string FirstName { get; set; }

        [Display(Name = "Middle Name")]
        public virtual string MiddleName { get; set; }
        //END Name

        [Display(Name = "Rate (per minute)")]

        //[DefaultValue(0)]
        [DefaultValue('9')]
        public virtual decimal CrewRate { get; set; }

        [Required]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; }

        //Primary Info
        #region
        //Birthdate
        [Required(ErrorMessage = "You must be over 21 years old to apply.")]
        [DataType(DataType.Date)]
        [Display(Name = "Birthdate")]
        public virtual DateTime Birthdate { get; set; }

        //Mobile Number
        [Required]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{5})$", ErrorMessage = "Please input a valid Mobile Number")]
        [Display(Name = "Mobile Number")]
        public virtual string MobileNumber { get; set; }

        //Present Address
        //[Required]
        [Display(Name = "Present Address")]
        public virtual string PresentAddress { get; set; }

        //Requirements
        [Display(Name = "Certificate")]
        public virtual int CertificateID { get; set; }
        public virtual Certificate Certificate { get; set; }

        [Display(Name = "License")]
        public virtual int LicenseID { get; set; }
        public virtual License License { get; set; }
        //END Requirements
        #endregion
        //END Primary Info

        //Additional Info
        #region 
        //Additional Info
        [Display(Name = "SSS Number")]
        public virtual string SSSNumber { get; set; }

        [Display(Name = "TIN Number")]
        public virtual string TinNumber { get; set; }

        [Display(Name = "Pagibig")]
        public virtual string Pagibig { get; set; }

        [Display(Name = "Philhealth")]
        public virtual string PhilHealth { get; set; }
        //END Additional Info
        #endregion 


        //Date Available
        
        [Required(ErrorMessage = "Date Available must not be a past date.")]
        [Display(Name = "Date Available")]
        [DataType(DataType.Date)]
        public virtual DateTime DateAvailable { get; set; }

        //FK - Status //Pass, Fail, Pending
        [Display(Name = "Status")]
        [DefaultValue(1)]
        public virtual int ApplicantStatusID { get; set; }
        public virtual ApplicantStatus ApplicantStatus { get; set; }

        [Display(Name = "Full Name")]
        public string FullName
        {
            get
            {
                return LastName + ", " + FirstName + " " + MiddleName;
            }
        }

        #region
        //Input on report page itself.
        //Format
        //  
        //(   signature   )
        //Jason A. Morales
        //   HR Manager
        //
        //[Required]
        //[Display(Name = "Created by: ")]
        //public virtual string CreatedBy { get; set; }

        //Input DateToday() in report page
        //[Required]
        //[Display(Name = "Date Created: ")]
        //[DataType(DataType.Date)]
        //public virtual string DateCreated { get; set; }

        //[Display(Name = "Date Modified: (if edited)")]
        //[DataType(DataType.Date)]
        //public virtual string DateModified { get; set; }
        #endregion

    }

    public class CrewStatus
    {
        //Primary Key
        public virtual int CrewStatusID { get; set; }
        //On-Board, On-Vacation, Inactive
        [Display(Name = "Status")]
        public virtual string CrewStatusName { get; set; }
    }

    public class ApplicantStatus
    {
        //Primary Key
        public virtual int ApplicantStatusID { get; set; }

        //Accepted, Rejected, Pending
        [Display(Name = "Applicant Status")]
        public virtual string ApplicantStatusName { get; set; }
    }
}