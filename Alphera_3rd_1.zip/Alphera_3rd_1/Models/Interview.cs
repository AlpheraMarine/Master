﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Alphera_3rd_1.Models
{
    //Schedule 
    //Set Date and Time of Interview
    public class Interview
    {
        public virtual int InterviewID { get; set; }
        public virtual int ApplicantID { get; set; }
        public virtual string InterviewTitle { get; set; }

        [Display(Name = "Date")]
        [Required(ErrorMessage = "Interview date must not be past date.")]
        [DataType(DataType.Date)]
        public virtual DateTime InterviewDate {get;set;}


        [Display(Name = "Time")]
        [DataType(DataType.Time)]
        public virtual DateTime InterviewTime { get; set; }


        public virtual int InterviewResultStatusID { get; set; }
        public virtual string InterviewRemark { get; set; }
        public virtual InterviewResultStatus InterviewResultStatus { get; set; }


        public virtual Applicant Applicant { get; set; }

    }


    public class InterviewResultStatus
    {
        public virtual int InterviewResultStatusID { get; set; }
        [Display(Name = "Result")]
        public virtual string InterviewResultStatusName { get; set; }

    }

}