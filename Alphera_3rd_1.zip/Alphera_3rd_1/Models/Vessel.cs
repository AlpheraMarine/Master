﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
/*
 * Must be able to add vessels for CREW to be assigned on
 * 
 * 1. Vessel must have a next Port 
 *      Next Port is the Port the vessel is currently travelling to
 *      
 * 2. Port must have a PORT NAME and COUNTRY of Origin
 * 3.
 * */

namespace Alphera_3rd_1.Models
{
    public class Vessel
    {
        //Primary Key
        public virtual int VesselID { get; set; }

        [Required]
        [Display(Name = "Vessel")]
        public virtual string VesselName { get; set; }

        //Current Port
        //[Required]
        //[Display(Name = "Current Port")]
        //public virtual int CurrentPortID { get; set; }
        //public virtual CurrentPort CurrentPort { get; set; }

        //Next Port
        [Required]
        [Display(Name = "Next Port")]
        public virtual int PortID { get; set; }
        public virtual Port Port { get; set; }

    }

    public class Port
    {
        //Primary Key
        public virtual int PortID { get; set; }

        [Display(Name = "Port Name")]
        public virtual string PortName { get; set; }

        //FK - In case of Separate Adding of Country Data
        [Display(Name = "Country")]
        public virtual string Country { get; set; }
        //public virtual int CountryID { get; set; }
        //public virtual Country Country { get; set; } 
    }

    //public class CurrentPort
    //{
    //    //Primary Key
    //    public virtual int CurrentPortID { get; set; }

    //    [Display(Name = "Current Port")]
    //    public virtual int PortID { get; set; }
    //    public virtual Port Port { get; set; }
    //}

    }

    /*
    public class Country
    {
        //Primary Key
        public virtual int CountryID { get; set; }

        [Required]
        [Display(Name = "Country")]
        public virtual string CountryName { get; set; }
    }
    */
