namespace Alphera_3rd_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class removedpayrollstatus : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Payrolls", "PayrollStatusID", "dbo.PayrollStatus");
            DropIndex("dbo.Payrolls", new[] { "PayrollStatusID" });
            DropColumn("dbo.Payrolls", "PayrollStatusID");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Payrolls", "PayrollStatusID", c => c.Int(nullable: false));
            CreateIndex("dbo.Payrolls", "PayrollStatusID");
            AddForeignKey("dbo.Payrolls", "PayrollStatusID", "dbo.PayrollStatus", "PayrollStatusID", cascadeDelete: true);
        }
    }
}
