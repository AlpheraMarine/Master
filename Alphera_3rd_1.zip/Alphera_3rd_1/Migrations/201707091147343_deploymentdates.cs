namespace Alphera_3rd_1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class deploymentdates : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Deployments", "SignOn", c => c.DateTime(nullable: false));
            AlterColumn("dbo.Deployments", "SignOff", c => c.DateTime(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Deployments", "SignOff", c => c.String());
            AlterColumn("dbo.Deployments", "SignOn", c => c.String());
        }
    }
}
