﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using Microsoft.Reporting.WebForms;
using System.IO;
using System.Web;
using System.Web.Mvc;
using Alphera_3rd_1.Models;

namespace Alphera_3rd_1.Controllers
{
    public class PayrollController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Payroll
        public ActionResult Index()
        {

            int applicantStatusUtility = 8;


            var payrolls = from p in db.Payrolls
                           orderby p.ApplicantID
                           where p.Applicant.ApplicantStatusID == applicantStatusUtility
                           select p;
            return View(payrolls.ToList());
        }

        // GET: Payroll/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Payroll payroll = db.Payrolls.Find(id);
            if (payroll == null)
            {
                return HttpNotFound();
            }
            return View(payroll);
        }


        public ActionResult Report(string id)
        {
            LocalReport lr = new LocalReport();
            string path = Path.Combine(Server.MapPath("~/Reports"), "Payroll.rdlc");
            if (System.IO.File.Exists(path))
            {
                lr.ReportPath = path;
            }
            else
            {
                return View("Index");
            }
            List<Payroll> cm = new List<Payroll>();
            using (ApplicationDbContext dc = new ApplicationDbContext())
            {
                cm = dc.Payrolls.ToList();
            }
            ReportDataSource rd = new ReportDataSource("Payroll", cm);
            lr.DataSources.Add(rd);
            string reportType = id;
            string mimeType;
            string encoding;
            string fileNameExtension;



            string deviceInfo =

            "<DeviceInfo>" +
            "  <OutputFormat>" + id + "</OutputFormat>" +
            "  <PageWidth>8.5in</PageWidth>" +
            "  <PageHeight>11in</PageHeight>" +
            "  <MarginTop>0.5in</MarginTop>" +
            "  <MarginLeft>1in</MarginLeft>" +
            "  <MarginRight>1in</MarginRight>" +
            "  <MarginBottom>0.5in</MarginBottom>" +
            "</DeviceInfo>";

            Warning[] warnings;
            string[] streams;
            byte[] renderedBytes;

            renderedBytes = lr.Render(
                reportType,
                deviceInfo,
                out mimeType,
                out encoding,
                out fileNameExtension,
                out streams,
                out warnings);
            return File(renderedBytes, mimeType);
        }

        // GET: Payroll/Create
        public ActionResult Create()
        {
            string applicantStatus = "Utility Service";
            ViewBag.ApplicantID = new SelectList(db.Applicants.Where(a => a.ApplicantStatus.ApplicantStatusName == applicantStatus), "ApplicantID", "FullName");
            ViewBag.PayrollStatusID = new SelectList(db.PayrollStatus, "PayrollStatusID", "PayrollStatusName");
            return View();
        }

        // POST: Payroll/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "PayrollID,ApplicantID,DateAttended,Date,TimeIn,TimeOut,GrossPay")] Payroll payroll)
        {
            //Applicant applicant = new Applicant();
            //int applicantID = payroll.ApplicantID;

            //applicant = (from a in db.Applicants
            //             where a.ApplicantID == applicantID
            //             select a).First();

            if (ModelState.IsValid)
            {
                payroll.Date = DateTime.Today;

                db.Payrolls.Add(payroll);

                //Reject - Date Attendance is in future
                if (payroll.DateAttended > DateTime.Now)
                {
                    TempData["notice"] = "Can not input future date.";
                    return RedirectToAction("Create");
                }

                else if (payroll.DateAttended <= DateTime.Now)
                {

                    //put computations here
                    DateTime ti = payroll.TimeIn;
                    DateTime to = payroll.TimeOut;
                    //abc = -Math.Abs(abc);

                    TimeSpan ts = ti.Subtract(to);

                    string totalStr = (ts.TotalMinutes).ToString();
                    int totalMinutes = Convert.ToInt32(totalStr); //-(int)60

                    Applicant applicantspecific = db.Applicants.Where(p => p.ApplicantID == payroll.ApplicantID).SingleOrDefault();

                    Response.Write(totalMinutes + "<br />");
                    Response.Write(applicantspecific.CrewRate + "<br/>");

                    Decimal grossPay = Convert.ToDecimal(totalMinutes) * applicantspecific.CrewRate * (-1);
                   
                    Response.Write("Gross Pay: " + grossPay + "<br/>");
                    Response.Write("Name: " + applicantspecific.FullName + "<br/>");

                    db.Payrolls.Add(payroll);
                    payroll.GrossPay = grossPay;
                    db.SaveChanges();

                    return RedirectToAction("Index");
                }

                db.SaveChanges();

                return RedirectToAction("Index");
            }

            ViewBag.ApplicantID = new SelectList(db.Applicants, "ApplicantID", "FullName", payroll.ApplicantID);
            //ViewBag.PayrollStatusID = new SelectList(db.PayrollStatus, "PayrollStatusID", "PayrollStatusName", payroll.PayrollStatusID);
            return View(payroll);
        }

        // GET: Payroll/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Payroll payroll = db.Payrolls.Find(id);
            if (payroll == null)
            {
                return HttpNotFound();
            }
            ViewBag.ApplicantID = new SelectList(db.Applicants, "ApplicantID", "FullName", payroll.ApplicantID);
            //ViewBag.PayrollStatusID = new SelectList(db.PayrollStatus, "PayrollStatusID", "PayrollStatusName", payroll.PayrollStatusID);
            return View(payroll);
        }

        // POST: Payroll/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "PayrollID,ApplicantID,DateAttended,Date,TimeIn,TimeOut,GrossPay")] Payroll payroll)
        {
            if (ModelState.IsValid)
            {
                db.Entry(payroll).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ApplicantID = new SelectList(db.Applicants, "ApplicantID", "FullName", payroll.ApplicantID);
            //ViewBag.PayrollStatusID = new SelectList(db.PayrollStatus, "PayrollStatusID", "PayrollStatusName", payroll.PayrollStatusID);
            return View(payroll);
        }

        // GET: Payroll/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Payroll payroll = db.Payrolls.Find(id);
            if (payroll == null)
            {
                return HttpNotFound();
            }
            return View(payroll);
        }

        // POST: Payroll/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Payroll payroll = db.Payrolls.Find(id);
            db.Payrolls.Remove(payroll);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
